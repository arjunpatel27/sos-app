package com.wafflecopter.multicontactpicker;

public enum LimitColumn {
    EMAIL,
    PHONE,
    NONE
}
