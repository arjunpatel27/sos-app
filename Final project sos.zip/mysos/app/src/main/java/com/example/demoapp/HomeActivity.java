package com.example.demoapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class HomeActivity extends AppCompatActivity {
    public static final int MULTIPLE_PERMISSIONS = 1;
    Button btn_logout;
    RelativeLayout rl_main;
    Button btn_save_our_soul, btn_zone;
    ImageView img_setting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        askPermissions();

        rl_main = findViewById(R.id.rl_main);
        btn_zone = findViewById(R.id.btn_zone);
        btn_save_our_soul = findViewById(R.id.btn_save_our_soul);
        btn_save_our_soul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                rl_main.setBackgroundColor(Color.parseColor("#f48d87"));
//                btn_save_our_soul.setBackgroundColor(Color.parseColor("#e7535f"));
//                btn_zone.setBackgroundColor(Color.parseColor("#e7535f"));
//                btn_zone.setText("RED");
                startActivity(new Intent(HomeActivity.this, HomeActivity2.class));
            }
        });

        btn_logout = findViewById(R.id.btn_logout);
        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log_out_Dialog();
            }
        });

        img_setting = findViewById(R.id.img_setting);
        img_setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomeActivity.this,SelectedContactDisaplyActivity.class));
            }
        });

    }

    private void askPermissions() {

        int permissionCheckWriteStorage = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int permissionContact = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS);

        if (Build.VERSION.SDK_INT >= 26) {
            if (permissionCheckWriteStorage == PackageManager.PERMISSION_GRANTED && permissionContact == PackageManager.PERMISSION_GRANTED ) {

            } else if (permissionCheckWriteStorage != PackageManager.PERMISSION_GRANTED && permissionContact != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.READ_CONTACTS},
                        MULTIPLE_PERMISSIONS);

            } else {
                Perm_storage("You need to give storage permission & contact permission.");
            }
        } else {

            if (permissionCheckWriteStorage == PackageManager.PERMISSION_GRANTED && permissionContact == PackageManager.PERMISSION_GRANTED) {

            } else if (permissionCheckWriteStorage != PackageManager.PERMISSION_GRANTED && permissionContact != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.READ_CONTACTS},
                        MULTIPLE_PERMISSIONS);

            } else {
                Perm_storage("You need to give storage permission & contact permission.");
            }
        }
    }

    private void Perm_storage(String msg) {
        AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this);
        builder.setCancelable(false);
        builder.setMessage(msg);
        builder.setPositiveButton("Grant", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                ActivityCompat.requestPermissions(HomeActivity.this, new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_EXTERNAL_STORAGE}, MULTIPLE_PERMISSIONS);
                dialog.cancel();
            }
        }).setNegativeButton("Open Setting", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", getPackageName(), null)));
                dialog.cancel();
            }
        });
        builder.show();
    }

    // Logout Dialog
    public void Log_out_Dialog() {
        AlertDialog.Builder builder;
        builder = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.CustomDialogTheme));
        builder.setMessage("Are you sure want to Logout?").setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int id) {
                        Clear_Shared_Preference(HomeActivity.this);
                        finish();
                        Intent login = new Intent(HomeActivity.this, LoginActivity.class);
                        startActivity(login);
                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }

        }).show();
    }

    // CLEAR ALL SHARED PREFERENCE
    public static void Clear_Shared_Preference(Context c) {
        SharedPreferences clear_user = c.getSharedPreferences("USER_PREFRENCE", MODE_PRIVATE);
        clear_user.edit().clear().commit();
    }
}