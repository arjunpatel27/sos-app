package com.example.demoapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.wafflecopter.multicontactpicker.ContactResult;
import com.wafflecopter.multicontactpicker.LimitColumn;
import com.wafflecopter.multicontactpicker.MultiContactPicker;

import java.util.ArrayList;

import io.paperdb.Paper;

public class SettingContact extends AppCompatActivity implements View.OnClickListener {
    Activity context;

    TextView txt_c1,txt_c2,txt_c3,txt_c4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting_contact);
        context = this;
        txt_c1=findViewById(R.id.txt_c1);
        txt_c2=findViewById(R.id.txt_c2);
        txt_c3=findViewById(R.id.txt_c3);
        txt_c4=findViewById(R.id.txt_c4);
        try {
            results = Paper.book().read("contacts");
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(results==null){
            results= new ArrayList<>();
        }
        setContact();
    }

    private static final int CONTACT_PICKER_REQUEST = 991;
    private ArrayList<ContactResult> results = new ArrayList<>();

    public void selectGroup() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            new MultiContactPicker.Builder(context) //Activity/fragment context
                    .theme(R.style.MyCustomPickerTheme) //Optional - default: MultiContactPicker.Azure
                    .hideScrollbar(false) //Optional - default: false
                    .showTrack(true) //Optional - default: true
                    .searchIconColor(Color.WHITE) //Option - default: White
                    .setChoiceMode(MultiContactPicker.CHOICE_MODE_MULTIPLE) //Optional - default: CHOICE_MODE_MULTIPLE
                    .handleColor(ContextCompat.getColor(context, R.color.colorPrimary_light)) //Optional - default: Azure Blue
                    .bubbleColor(ContextCompat.getColor(context, R.color.colorPrimaryDark_light)) //Optional - default: Azure Blue
                    .bubbleTextColor(Color.WHITE) //Optional - default: White
                    .setTitleText("Select Contacts") //Optional - default: Select Contacts
                    .setSelectedContacts(results) //Optional - will pre-select contacts of your choice. String... or List<ContactResult>
                    .setLoadingType(MultiContactPicker.LOAD_SYNC) //Optional - default LOAD_ASYNC (wait till all loaded vs stream results)
                    .limitToColumn(LimitColumn.PHONE) //Optional - default NONE (Include phone + email, limiting to one can improve loading time)
                    .setActivityAnimations(android.R.anim.fade_in, android.R.anim.fade_out,
                            android.R.anim.fade_in,
                            android.R.anim.fade_out) //Optional - default: No animation overrides
                    .showPickerForResult(CONTACT_PICKER_REQUEST);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CONTACT_PICKER_REQUEST) {
            if (resultCode == RESULT_OK) {
//                for (ContactResult contactResult : results) {
//                    if (contactResult.getDisplayName().equals(MultiContactPicker.obtainResult(data).get(0).getDisplayName())) {
//                        return;
//                    }
//                }

//                if (results.size() > 3) {
//                    results.remove(results.size() - 1);
//                }
                results = new ArrayList<>();
                results.addAll(MultiContactPicker.obtainResult(data));
                Log.d("MyTag", results.size() + "");
                setContact();

            } else if (resultCode == RESULT_CANCELED) {
                System.out.println("User closed the picker without selecting items.");
            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_back:
                onBackPressed();
                break;
            case R.id.lv_c1:
            case R.id.lv_c2:
            case R.id.lv_c3:
            case R.id.lv_c4:
            case R.id.lv_search:
                selectGroup();
                break;
            case R.id.btn_close_c1:
                if (results.size()>=1){
                    results.remove(0);
                }
                setContact();
                break;
            case R.id.btn_close_c2:
                if (results.size()>=2){
                    results.remove(1);
                }
                setContact();
                break;
            case R.id.btn_close_c3:
                if (results.size()>=3){
                    results.remove(2);
                }
                setContact();
                break;
            case R.id.btn_close_c4:
                if (results.size()>=4){
                    results.remove(3);
                }
                setContact();
                break;
            case R.id.btn_amb:
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:108"));//change the number
                startActivity(callIntent);
                break;
            case R.id.btn_polish:
                Intent callIntent1 = new Intent(Intent.ACTION_CALL);
                callIntent1.setData(Uri.parse("tel:100"));//change the number
                startActivity(callIntent1);
                break;
            case R.id.btn_fire:
                Intent callIntent2 = new Intent(Intent.ACTION_CALL);
                callIntent2.setData(Uri.parse("tel:101"));//change the number
                startActivity(callIntent2);
                break;
        }
    }

    public void setContact(){
        try {
            Paper.book().write("contacts", results);
            if(results.size()>=1){
                txt_c1.setText(results.get(0).getDisplayName());
            }else {
                txt_c1.setText("Empty");
            }
            if(results.size()>=2){
                txt_c2.setText(results.get(1).getDisplayName());
            }else {
                txt_c2.setText("Empty");
            }
            if(results.size()>=3){
                txt_c3.setText(results.get(2).getDisplayName());
            }else {
                txt_c3.setText("Empty");
            }
            if(results.size()>=4){
                txt_c4.setText(results.get(3).getDisplayName());
            }else {
                txt_c4.setText("Empty");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}