package com.example.demoapp;


import static com.example.demoapp.DashBoard.NOTIFICATION_CHANNEL_ID;

import static java.security.AccessController.getContext;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.app.NotificationCompat;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.protobuf.StringValue;

import java.lang.reflect.Member;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class user_Detail extends AppCompatActivity {
    ImageView cal1,cal2,cal3,backbtn1;
    TextView startdate,enddate,birthdate;
    TextInputEditText names,mail,ages,illness,adharnum,ins,policy,pin,add,inject,tablet,syrup;
    AppCompatButton delete,save;
    private   RadioGroup gen,insurance,nameill,medicinetake;
    RadioButton male,female,rbtnyes,rbtnno,yesbtn,nobtn,yes,no;
    int y,m,d;
    public CheckBox check1,check2,check3,c1,c2,c3;
    Spinner blood,compny,state;
    private final static String default_notification_channel_id = "default" ;
    ArrayList<String> arryid=new ArrayList<>();
    ArrayList<String> arry=new ArrayList<>();
    ArrayList<String> arrycom=new ArrayList<>();
    private String selectedDistrict, selectedState;
    final Calendar myCalendar = Calendar. getInstance () ;
    private Spinner stateSpinner, districtSpinner,medicinespinner;
    private ArrayAdapter<CharSequence> stateAdapter, districtAdapter;
    private SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    int i=0;
    private String gender = "";
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    Userinfo userinfo;
    Member member;
    int maxid =0;
    private static final String KEY_CHECKBOX = "key_checkbox";




    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_detail);

        c1=findViewById(R.id.check1);
        c2=findViewById(R.id.check2);
        c3=findViewById(R.id.check3);
        check1 = (CheckBox)findViewById(R.id.check1);
        check2 = (CheckBox)findViewById(R.id.check2);
        check3 = (CheckBox)findViewById(R.id.check3);
        names= (TextInputEditText) findViewById(R.id.name);
       mail= (TextInputEditText) findViewById(R.id.email);
       ages = (TextInputEditText) findViewById(R.id.age);
       illness=  (TextInputEditText) findViewById(R.id.illessname);
        inject=  (TextInputEditText) findViewById(R.id.inj);
        tablet =  (TextInputEditText) findViewById(R.id.tab);
        syrup =  (TextInputEditText) findViewById(R.id.syp);
       adharnum= (TextInputEditText) findViewById(R.id.adhar);
       ins= (TextInputEditText) findViewById(R.id.insurancenum);
       policy=(TextInputEditText) findViewById(R.id.amount);
       pin= (TextInputEditText) findViewById(R.id.pincode);
       add= (TextInputEditText) findViewById(R.id.edt_note);
       startdate=(TextView) findViewById(R.id.startdate);
        birthdate=(TextView) findViewById(R.id.birthdate);
        enddate=(TextView) findViewById(R.id.enddate);
       blood= (Spinner) findViewById(R.id.bloodspn);
       medicinespinner=(Spinner) findViewById(R.id.medicnecount);




        Intent myIntent = new Intent(getApplicationContext() , user_Detail. class ) ;
        AlarmManager alarmManager = (AlarmManager) getSystemService( ALARM_SERVICE ) ;
        PendingIntent pendingIntent = PendingIntent. getService ( this, 0 , myIntent , 0 ) ;
        Calendar calendar = Calendar. getInstance () ;
        calendar.set(Calendar. SECOND , 0 ) ;
        calendar.set(Calendar. MINUTE , 0 ) ;
        calendar.set(Calendar. HOUR , 0 ) ;
        calendar.set(Calendar. AM_PM , Calendar. AM ) ;
        calendar.add(Calendar. DAY_OF_MONTH , 1 ) ;
        alarmManager.setRepeating(AlarmManager. RTC_WAKEUP , calendar.getTimeInMillis() , 1000 * 60 * 60 * 24 , pendingIntent) ;





        delete=(AppCompatButton) findViewById(R.id.clear);
        save=(AppCompatButton) findViewById(R.id.savebtn);


        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getInstance().getReference().child("userinfo");
        userinfo = new Userinfo();

       sharedPreferences=getSharedPreferences("DATA",MODE_PRIVATE);
       int gender = sharedPreferences.getInt("gender",3);
       int vimo =  sharedPreferences.getInt("vimo",2);
       int illlname = sharedPreferences.getInt("illlname",6);
        int medicine = sharedPreferences.getInt("medicine",5);

        editor = sharedPreferences.edit();
        gen=findViewById(R.id.gender);
        female= findViewById(R.id.female);
        male= findViewById(R.id.male);


        if (gender==1){
            male.setChecked(true);}
        else if (gender==0){
            female.setChecked(true);
        }

        medicinetake =findViewById(R.id.medicinetake);
        yes=findViewById(R.id.yes);
        no=findViewById(R.id.no);
        insurance =findViewById(R.id.insurance);
        rbtnyes =findViewById(R.id.rbtnyes);
        rbtnno=findViewById(R.id.rbtnno);
        if (medicine==1){
            yes.setChecked(true);}
        else if (medicine==0){
            no.setChecked(true);
        }


        if (vimo==1){
            rbtnyes.setChecked(true);}
        else if (vimo==0){
            rbtnno.setChecked(true);
        }


        nameill=findViewById(R.id.nameill);
        yesbtn=findViewById(R.id.yesbtn);
        nobtn=findViewById(R.id.nobtn);

        if (illlname==1){
            yesbtn.setChecked(true);}
        else if (illlname==0){
            nobtn.setChecked(true);
        }

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {





                String name = names.getText().toString();
                String adhar = adharnum.getText().toString();
                String address = add.getText().toString();
                String email =mail.getText().toString();
                String birthdates =birthdate.getText().toString();
                String Age =ages.getText().toString();
                String Pincode = pin.getText().toString();
                String Policynum =ins.getText().toString();
                String Policyamount =policy.getText().toString();
                String Policystart =startdate.getText().toString();
                String Policyend =enddate.getText().toString();
                String IllnessName =illness.getText().toString();
                String Injection =inject.getText().toString();
                String Tablet =tablet.getText().toString();
                String Syrup =syrup.getText().toString();
                String m1=male.getText().toString();
                String m2 =female.getText().toString();
                String m3=c1.getText().toString();
                String m4=c2.getText().toString();
                String m5=c3.getText().toString();
                String m6=rbtnyes.getText().toString();
                String m7=rbtnno.getText().toString();
                String m8=yesbtn.getText().toString();
                String m9=nobtn.getText().toString();
                String m11=yes.getText().toString();
                String m12=no.getText().toString();


                if(yesbtn.isChecked()){
                    userinfo.setIllnessavaliable(m8);
                    databaseReference.child(String.valueOf(maxid+1)).setValue(userinfo);
                }else{
                    userinfo.setIllnessavaliable(m9);
                    databaseReference.child(String.valueOf(maxid+1)).setValue(userinfo);
                }


                if(yes.isChecked()){
                    userinfo.setMedicinetakedaily(m11);
                    databaseReference.child(String.valueOf(maxid+1)).setValue(userinfo);
                }else{
                    userinfo.setMedicinetakedaily(m12);
                    databaseReference.child(String.valueOf(maxid+1)).setValue(userinfo);
                }


                if(male.isChecked()){
                     userinfo.setGender(m1);
                     databaseReference.child(String.valueOf(maxid+1)).setValue(userinfo);
                 }else{
                     userinfo.setGender(m2);
                    databaseReference.child(String.valueOf(maxid+1)).setValue(userinfo);
                }

                if(rbtnyes.isChecked()){
                    userinfo.setInsurancepolicyAvaliable(m6);
                    databaseReference.child(String.valueOf(maxid+1)).setValue(userinfo);
                }else{
                    userinfo.setInsurancepolicyAvaliable(m7);
                    databaseReference.child(String.valueOf(maxid+1)).setValue(userinfo);
                }



                if(c1.isChecked()){
                    userinfo.setTypeofmedicine(m3);
                    databaseReference.child(String.valueOf(maxid+1)).setValue(userinfo);
                }
                if(c2.isChecked()){
                    userinfo.setTypeofmedicine(m4);
                    databaseReference.child(String.valueOf(maxid+1)).setValue(userinfo);}
                else{
                    userinfo.setTypeofmedicine(m5);
                    databaseReference.child(String.valueOf(maxid+1)).setValue(userinfo);
                }




                if (TextUtils.isEmpty(name) && TextUtils.isEmpty(email) && TextUtils.isEmpty(birthdates) && TextUtils.isEmpty(Age)) {
                    // if the text fields are empty
                    // then show the below message.
                    databaseReference.child(String.valueOf(maxid+1)).setValue(userinfo);
                    Toast.makeText(user_Detail.this, "Please add some data.", Toast.LENGTH_SHORT).show();
                } else {
                    // else call the method to add
                    // data to our database.

                    addDatatoFirebase(name, adhar, address,email,birthdates,Age,Pincode,Policynum,Policyamount,Policystart,Policyend,IllnessName,Injection,Tablet,Syrup);

                }






            }


        });


medicinetake.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        if(checkedId==R.id.yes){
            editor.putInt("medicine",1);
        }
        else if (checkedId==R.id.no){
            editor.putInt("medicine",0);
        }
        editor.commit();
    }
});
        nameill.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId==R.id.yesbtn){
                    editor.putInt("illlname",1);
                }
                else if (checkedId==R.id.nobtn){
                    editor.putInt("illlname",0);
                }
                editor.commit();
            }
        });

        insurance.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId==R.id.rbtnyes){
                    editor.putInt("vimo",1);
                }
                else if (checkedId==R.id.rbtnno){
                    editor.putInt("vimo",0);
                }
                editor.commit();
            }
        });

            gen.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    if(checkedId==R.id.male){
                        editor.putInt("gender",1);
                    }
                    else if (checkedId==R.id.female){
                        editor.putInt("gender",0);
                    }
                    editor.commit();
                }
            });



        cal1=findViewById(R.id.cal1);
        cal2=findViewById(R.id.cal2);
        cal3=findViewById(R.id.cal3);
        backbtn1=findViewById(R.id.backbtn1);
        blood=findViewById(R.id.bloodspn);
        medicinespinner=findViewById(R.id.medicnecount);

        compny=findViewById(R.id.company);
        startdate=findViewById(R.id.startdate);
        birthdate=findViewById(R.id.birthdate);
        enddate=findViewById(R.id.enddate);
        stateSpinner = findViewById(R.id.spinner_indian_states);
        stateAdapter = ArrayAdapter.createFromResource(user_Detail.this, R.array.array_indian_states,R.layout.spinner_layout);
        stateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        stateSpinner.setAdapter(stateAdapter);


        gen = findViewById(R.id.gender);


        final Calendar c=Calendar.getInstance();
        cal1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                y=c.get(Calendar.YEAR);
                m=c.get(Calendar.MONTH);
                d=c.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog g=new DatePickerDialog(user_Detail.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        startdate.setText(dayOfMonth+"/"+month+"/"+year);
                    }
                },y,m,d);
                g.show();
            }
        });

        cal3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                y=c.get(Calendar.YEAR);
                m=c.get(Calendar.MONTH);
                d=c.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog g=new DatePickerDialog(user_Detail.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        birthdate.setText(dayOfMonth+"/"+month+"/"+year);
                    }
                },y,m,d);
                g.show();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {




                SharedPreferences.Editor editor=sharedPreferences.edit();
                editor.clear();
                editor.commit();
                names.setText("");
                mail.setText("");
                illness.setText("");
                adharnum.setText("");
                ages.setText("");
                ins.setText("");
                policy.setText("");
                pin.setText("");
                add.setText("");
                inject.setText("");
                syrup.setText("");
                tablet.setText("");
                startdate.setText("");
                enddate.setText("");
                birthdate.setText("");


            }
        });


        cal2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                y=c.get(Calendar.YEAR);
                m=c.get(Calendar.MONTH);
                d=c.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog g=new DatePickerDialog(user_Detail.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        enddate.setText(dayOfMonth+"/"+month+"/"+year);
                    }
                },y,m,d);
                g.show();
            }
        });



        stateSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                districtSpinner = findViewById(R.id.spinner_indian_districts);

                selectedState = stateSpinner.getSelectedItem().toString();

                int parentID = parent.getId();
                if (parentID == R.id.spinner_indian_states){
                    switch (selectedState){
                        case "Select Your State": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_default_districts, R.layout.spinner_layout);
                            break;
                        case "Andhra Pradesh": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_andhra_pradesh_districts, R.layout.spinner_layout);
                            break;
                        case "Arunachal Pradesh": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_arunachal_pradesh_districts, R.layout.spinner_layout);
                            break;
                        case "Assam": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_assam_districts, R.layout.spinner_layout);
                            break;
                        case "Bihar": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_bihar_districts, R.layout.spinner_layout);
                            break;
                        case "Chhattisgarh": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_chhattisgarh_districts, R.layout.spinner_layout);
                            break;
                        case "Goa": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_goa_districts, R.layout.spinner_layout);
                            break;
                        case "Gujarat": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_gujarat_districts, R.layout.spinner_layout);
                            break;
                        case "Haryana": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_haryana_districts, R.layout.spinner_layout);
                            break;
                        case "Himachal Pradesh": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_himachal_pradesh_districts, R.layout.spinner_layout);
                            break;
                        case "Jharkhand": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_jharkhand_districts, R.layout.spinner_layout);
                            break;
                        case "Karnataka": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_karnataka_districts, R.layout.spinner_layout);
                            break;
                        case "Kerala": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_kerala_districts, R.layout.spinner_layout);
                            break;
                        case "Madhya Pradesh": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_madhya_pradesh_districts, R.layout.spinner_layout);
                            break;
                        case "Maharashtra": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_maharashtra_districts, R.layout.spinner_layout);
                            break;
                        case "Manipur": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_manipur_districts, R.layout.spinner_layout);
                            break;
                        case "Meghalaya": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_meghalaya_districts, R.layout.spinner_layout);
                            break;
                        case "Mizoram": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_mizoram_districts, R.layout.spinner_layout);
                            break;
                        case "Nagaland": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_nagaland_districts, R.layout.spinner_layout);
                            break;
                        case "Odisha": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_odisha_districts, R.layout.spinner_layout);
                            break;
                        case "Punjab": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_punjab_districts, R.layout.spinner_layout);
                            break;
                        case "Rajasthan": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_rajasthan_districts, R.layout.spinner_layout);
                            break;
                        case "Sikkim": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_sikkim_districts, R.layout.spinner_layout);
                            break;
                        case "Tamil Nadu": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_tamil_nadu_districts, R.layout.spinner_layout);
                            break;
                        case "Telangana": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_telangana_districts, R.layout.spinner_layout);
                            break;
                        case "Tripura": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_tripura_districts, R.layout.spinner_layout);
                            break;
                        case "Uttar Pradesh": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_uttar_pradesh_districts, R.layout.spinner_layout);
                            break;
                        case "Uttarakhand": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_uttarakhand_districts, R.layout.spinner_layout);
                            break;
                        case "West Bengal": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_west_bengal_districts, R.layout.spinner_layout);
                            break;
                        case "Andaman and Nicobar Islands": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_andaman_nicobar_districts, R.layout.spinner_layout);
                            break;
                        case "Chandigarh": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_chandigarh_districts, R.layout.spinner_layout);
                            break;
                        case "Dadra and Nagar Haveli": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_dadra_nagar_haveli_districts, R.layout.spinner_layout);
                            break;
                        case "Daman and Diu": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_daman_diu_districts, R.layout.spinner_layout);
                            break;
                        case "Delhi": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_delhi_districts, R.layout.spinner_layout);
                            break;
                        case "Jammu and Kashmir": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_jammu_kashmir_districts, R.layout.spinner_layout);
                            break;
                        case "Lakshadweep": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_lakshadweep_districts, R.layout.spinner_layout);
                            break;
                        case "Ladakh": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_ladakh_districts, R.layout.spinner_layout);
                            break;
                        case "Puducherry": districtAdapter = ArrayAdapter.createFromResource(parent.getContext(),
                                R.array.array_puducherry_districts, R.layout.spinner_layout);
                            break;
                        default:  break;
                    }
                    districtAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);     // Specify the layout to use when the list of choices appears
                    districtSpinner.setAdapter(districtAdapter);        //Populate the list of Districts in respect of the State selected

                    //To obtain the selected District from the spinner
                    districtSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            selectedDistrict = districtSpinner.getSelectedItem().toString();

                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {
                        }
                    });
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        arryid.add("Select Your Blood Group");
        arryid.add("A+");
        arryid.add("A-");
        arryid.add("B+");
        arryid.add("B+");
        arryid.add("O+");
        arryid.add("O-");
        arryid.add("AB+");
        arryid.add("AB-");
        ArrayAdapter<String> spinner=new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,arryid);

        blood.setAdapter(spinner);
        arry.add("Select How Much Medicine You Take");
        arry.add("Zero (0) ");
        arry.add("One (1)");
        arry.add("Two (2)");
        arry.add("Three (3)");
        arry.add("Four (4)");
        arry.add("Five (5)");
        arry.add("Six (6)");
        arry.add("Seven (7)");
        arry.add("Eight (8)");
        arry.add("Nine (9)");

        ArrayAdapter<String> spinners=new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,arry);

        medicinespinner.setAdapter(spinners);



        arrycom.add("Select Insurance Company");
        arrycom.add("Life Insurance Corporation of India");
        arrycom.add("Aditya Birla Sun Life Insurance");
        arrycom.add("Aditya Birla Health Insurance");
        arrycom.add("Aegon Life Insurance");
        arrycom.add("Ageas Federal Life Insurance");
        arrycom.add("Aviva Life");
        arrycom.add("Bajaj Allianz Life Insurance");
        arrycom.add("Bharti AXA Life Insurance");
        arrycom.add("Canara HSBC OBC Life Insurance");
        arrycom.add("Care Health Insurance");
        arrycom.add("Digit Insurance");
        arrycom.add("Edelweiss Tokio Life Insurance\n");
        arrycom.add("Exide Life Insurance");
        arrycom.add("Future Generali India Life Insurance Company Limited");
        arrycom.add("HDFC Life Insurance");
        arrycom.add("ICICI Lombard General Insurance (Health)");
        arrycom.add("ICICI Prudential Life Insurance");
        arrycom.add("IndiaFirst Life Insurance");
        arrycom.add("Kotak Life Insurance");
        arrycom.add("Manipal Cigna Health Insurance");
        arrycom.add("Niva Bupa Health Insurance Company Limited");
        arrycom.add("Max Life Insurance");
        arrycom.add("Oriental General Insurance");
        arrycom.add("Pramerica Life Insurance");
        arrycom.add("Reliance Health Insurance");
        arrycom.add("Reliance Nippon Life Insurance");
        arrycom.add("Royal Sundaram General Insurance Co. Limited");
        arrycom.add("SBI Life Insurance");
        arrycom.add("Shriram General Insurance");
        arrycom.add("Star Union Dai Ichi Life Insurance");
        arrycom.add("Tata AIA Life Insurance");
        arrycom.add("Other Insurance Company ");
        ArrayAdapter<String> com=new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,arrycom);
        compny.setAdapter(com);




    }


    private void scheduleNotification (Notification notification , long delay) {
        Intent notificationIntent = new Intent( this, MyNotificationPublisher. class ) ;
        notificationIntent.putExtra(MyNotificationPublisher. NOTIFICATION_ID , 1 ) ;
        notificationIntent.putExtra(MyNotificationPublisher. NOTIFICATION , notification) ;
        PendingIntent pendingIntent = PendingIntent. getBroadcast ( this, 0 , notificationIntent , PendingIntent. FLAG_UPDATE_CURRENT ) ;
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context. ALARM_SERVICE ) ;
        assert alarmManager != null;
        alarmManager.set(AlarmManager. ELAPSED_REALTIME_WAKEUP , delay , pendingIntent) ;

    }



    private void updateLabel () {
        String myFormat = "dd/MM/yy" ; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat , Locale. getDefault ()) ;
        Date date = myCalendar .getTime() ;
        enddate .setText(sdf.format(date)) ;
        scheduleNotification(getNotification( enddate .getText().toString()) , date.getTime()) ;
    }


    @Override
    protected void onResume(){
        super.onResume();
        SharedPreferences sh = getSharedPreferences("MySharedPref", MODE_PRIVATE);

        boolean isCheckBoxChecked = sh.getBoolean("KEY_CHECKBOX", true);
        boolean CheckBoxChecked = sh.getBoolean("CHECKBOX", true);
        boolean BoxChecked = sh.getBoolean("BOX", true);
        check1.setChecked(isCheckBoxChecked);
        check2.setChecked(CheckBoxChecked);
       check3.setChecked(BoxChecked);
        String s1 = sh.getString("names", "");
        String s2 = sh.getString("mail", "");
        String s5 = sh.getString("illness", "");
        String s4 = sh.getString("adharnum", "");
        String s3 = sh.getString("ages", "");
        String s6 = sh.getString("ins", "");
        String s7 = sh.getString("policy", "");
        String s8 = sh.getString("pin", "");
        String s9 = sh.getString("add", "");
        String inj = sh.getString("injection", "");
        String tab = sh.getString("tablet", "");
        String syr = sh.getString("syrup", "");
        String start = sh.getString("start", "");
        String end = sh.getString("end", "");
        String birth = sh.getString("birth", "");
        int index = sh.getInt("spinnerValue",0);
        int bloods = sh.getInt("blood",0);
        int company = sh.getInt("insurance",0);
        int district =sh.getInt("dis",0);
        int medicine=sh.getInt("medicine",0);
        stateSpinner.setSelection(index);

        blood.setSelection(bloods);
        compny.setSelection(company);
        medicinespinner.setSelection(medicine);






        
        names.setText(s1);
        mail.setText(s2);
        illness.setText(s5);
       adharnum.setText(s4);
        ages.setText(s3);
        ins.setText(s6);
        policy.setText(s7);
        pin.setText(s8);
      add.setText(s9);
        inject.setText(inj);
        tablet.setText(tab);
        syrup.setText(syr);
        startdate.setText(start);
        enddate.setText(end);
        birthdate.setText(birth);



    }


    @Override
    protected void onPause() {
        super.onPause();

        // Creating a shared pref object
        // with a file name "MySharedPref"
        // in private mode
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        SharedPreferences.Editor myEdit = sharedPreferences.edit();


        // write all the data entered by the user in SharedPreference and apply
       myEdit.putString("names", names.getText().toString());
        myEdit.putString("mail", mail.getText().toString());
        myEdit.putString("illness", illness.getText().toString());
        myEdit.putString("adharnum", adharnum.getText().toString());
        myEdit.putString("ages", ages.getText().toString());
        myEdit.putString("ins", ins.getText().toString());
        myEdit.putString("policy", policy.getText().toString());
        myEdit.putBoolean("male",false);
        myEdit.putString("pin", pin.getText().toString());

       myEdit.putString("add", add.getText().toString());

        myEdit.putString("injection", inject.getText().toString());
        myEdit.putString("tablet", tablet.getText().toString());
        myEdit.putString("syrup", syrup.getText().toString());
        myEdit.putString("start",startdate.getText().toString());
        myEdit.putString("end",enddate.getText().toString());
        myEdit.putString("birth",birthdate.getText().toString());
        myEdit.putBoolean("KEY_CHECKBOX",check1.isChecked());
       myEdit.putBoolean("CHECKBOX",check2.isChecked());
       myEdit.putBoolean("BOX",check3.isChecked());
        myEdit.putInt("spinnerValue",stateSpinner.getSelectedItemPosition());

        myEdit.putInt("blood",blood.getSelectedItemPosition());
        myEdit.putInt("insurance",compny.getSelectedItemPosition());
        myEdit.putInt("medicine",medicinespinner.getSelectedItemPosition());
        myEdit.putInt("dis",districtSpinner.getSelectedItemPosition());
        myEdit.apply();
    }




    public void back(View view) {
        finish();
    }

    public static class MyNotificationPublisher extends BroadcastReceiver {

        public static String NOTIFICATION_ID = "notification-id" ;
        public static String NOTIFICATION = "notification" ;
        public void onReceive (Context context , Intent intent) {
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE) ;
            Notification notification = intent.getParcelableExtra( NOTIFICATION ) ;
            if (android.os.Build.VERSION. SDK_INT >= android.os.Build.VERSION_CODES. O ) {
                int importance = NotificationManager. IMPORTANCE_HIGH ;
                NotificationChannel notificationChannel = new NotificationChannel( NOTIFICATION_CHANNEL_ID , "NOTIFICATION_CHANNEL_NAME" , importance) ;
                assert notificationManager != null;
                notificationManager.createNotificationChannel(notificationChannel) ;
            }
            int id = intent.getIntExtra( NOTIFICATION_ID , 0 ) ;
            assert notificationManager != null;
            notificationManager.notify(id , notification) ;
        }
    }



    private Notification getNotification (String content) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder( this, default_notification_channel_id ) ;
        builder.setContentTitle( "Scheduled Notification" ) ;
        builder.setContentText(content) ;
        builder.setSmallIcon(R.drawable. ic_launcher_foreground ) ;
        builder.setAutoCancel( true ) ;
        builder.setChannelId( NOTIFICATION_CHANNEL_ID ) ;
        return builder.build() ;
    }


    public  void btnclick(View view){
        boolean checked =((RadioButton) view).isChecked();
        switch (view.getId()){
        case R.id.rbtnyes:
        if (checked){
            editor.putInt("vimo",1);
        }
        break;
        case R.id.rbtnno:
        if (checked){
            editor.putInt("vimo",0);
        }
        break;
        }
        editor.commit();
    }

    public  void click(View view){
        boolean checked =((RadioButton) view).isChecked();
        switch (view.getId()){
            case R.id.yesbtn:
                if (checked){
                    editor.putInt("illlname",1);
                }
                break;
            case R.id.nobtn:
                if (checked){
                    editor.putInt("illlname",0);
                }
                break;
        }
        editor.commit();
    }

    public void medicine (View view){

        boolean checked =((RadioButton) view).isChecked();
        switch (view.getId()){

            case R.id.yes:
                if (checked){
                    editor.putInt("medicine",1);
                }
                break;
            case R.id.no:
                if (checked){
                    editor.putInt("medicine",0);
                }
                break;

        }
        editor.commit();
    }

    public void btnclicked(View view){

        boolean checked =((RadioButton) view).isChecked();
        switch (view.getId()){

            case R.id.male:
                if (checked){
                    editor.putInt("gender",1);
                }
                break;
            case R.id.female:
                if (checked){
                    editor.putInt("gender",0);
                }
                break;

        }
        editor.commit();
    }




    private void addDatatoFirebase(String name, String adhar, String address, String email, String birthdate, String age, String Pincode, String policynum, String policyamount, String policystart, String policyend, String illnessName, String injection, String tablet, String syrup) {

        userinfo.setUserName(name);
        userinfo.setUseradharNumber(adhar);

        userinfo.setUserAddress(address);
        userinfo.setUserEmail(email);
        userinfo.setBirthDate(birthdate);
        userinfo.setAge(age);
        userinfo.setPincode(Pincode);
        userinfo.setPolicyNumber(policynum);
        userinfo.setPolicyAmount(policyamount);
        userinfo.setPolicyStartDate(policystart);
        userinfo.setPolicyEndDate(policyend);
        userinfo.setIllnessName(illnessName);
        userinfo.setNameOfinjection(injection);
        userinfo.setNameOfTablet(tablet);
       // userinfo.setPassword(userinfo.getPassword());
        userinfo.setNameOfSyrup(syrup);
        userinfo.setTypeofmedicine(c1,c2,c3);
        userinfo.setBlood(blood.getSelectedItem().toString());
        userinfo.setInsurancecompany(compny.getSelectedItem().toString());
        userinfo.setState(stateSpinner.getSelectedItem().toString());
        userinfo.setDistrict(districtSpinner.getSelectedItem().toString());
        userinfo.setDailymedicinetake(medicinespinner.getSelectedItem().toString());





        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

            //  databaseReference.setValue(userinfo);
                    maxid=(int)snapshot.getChildrenCount();
                //databaseReference.child(String.valueOf(maxid+1)).setValue(userinfo);
                Toast.makeText(user_Detail.this, "data added" , Toast.LENGTH_SHORT).show();
            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // if the data is not added or it is cancelled then
                // we are displaying a failure toast message.
                Toast.makeText(user_Detail.this, "Fail to add data " + error, Toast.LENGTH_SHORT).show();
            }

        });
    }

}
