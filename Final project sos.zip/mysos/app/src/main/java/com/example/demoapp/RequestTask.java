package com.example.demoapp;


import android.os.AsyncTask;
import android.util.Log;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

class RequestTask extends AsyncTask<String, String, String> {
    @Override
    protected String doInBackground(String... uri) {
        //Do something meaningful.
//        HttpClient httpclient = new DefaultHttpClient();


//        HttpResponse response;
        String responseString = null;
        try {
            Log.d("UrlRequest=", "" + uri[0]);
            Log.d("Request=", "" + uri[1]);
            URL url = new URL("http://mysos.in/"+uri[0]);
            HttpURLConnection con = (HttpURLConnection)url.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json; utf-8");
            try(OutputStream os = con.getOutputStream()) {
                byte[] input = uri[1].getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            try(BufferedReader br = new BufferedReader(
                    new InputStreamReader(con.getInputStream(), "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
                System.out.println(response.toString());
                return  response.toString();
            }


//            HttpPost  post = new HttpPost("https://meet.heartitout.in/"+uri[0]);
//            StringEntity postingString = new StringEntity(uri[1]);//gson.tojson() converts your pojo to json
//            post.setEntity(postingString);
//            post.setHeader("Content-type", "application/json");
//             response = httpclient.execute(post);
//            StatusLine statusLine = response.getStatusLine();
//            if (statusLine.getStatusCode() == HttpStatus.SC_OK) {
//                ByteArrayOutputStream out = new ByteArrayOutputStream();
//                response.getEntity().writeTo(out);
//                responseString = out.toString();
//                Log.d("ResponseString=", "" + responseString);
//
//                out.close();
//            } else {
//                //Closes the connection.
//                response.getEntity().getContent().close();
//                throw new IOException(statusLine.getReasonPhrase());
//            }
        }  catch (Exception e) {
            responseString = e.getMessage();
            //TODO Handle problems..
        }
        return responseString;
    }
}
