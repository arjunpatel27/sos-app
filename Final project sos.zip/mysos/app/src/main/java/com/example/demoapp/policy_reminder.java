package com.example.demoapp;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class policy_reminder extends AppCompatActivity {
ImageView backbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_policy_reminder);

        backbtn=findViewById(R.id.backbtn);


    }

    public void back(View view) {

        finish();
    }
}