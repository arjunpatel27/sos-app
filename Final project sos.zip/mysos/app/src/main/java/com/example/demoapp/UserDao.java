package com.example.demoapp;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface UserDao {

    @Insert
    void insert(UserModel model);

    @Update
    void update(UserModel model);

    @Delete
    void delete(UserModel model);

    @Query("SELECT * FROM user_table where Phone=(:mobile) and Password=(:password)")
    UserModel login(String mobile, String password);

    @Query("SELECT * FROM user_table where Email= :email")
    UserModel check(String email);


    @Query("SELECT * FROM user_table where phone= :monile")
    UserModel findByNumber(String monile);


//    @Query("SELECT * FROM student_table where StudentPassword= :StudentPassword")
//    CourseModal update(String StudentPassword);

    @Query("SELECT * FROM user_table ORDER BY FullName ASC")
    List<UserModel> getAllCourses();

}

