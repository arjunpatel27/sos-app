package com.example.demoapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import org.json.JSONArray;

import java.util.HashMap;

public class Session {
    public static final String CustomerName = "name";
    public static final String MobileNo = "phone";
    private static final String PREF_NAME = "user";

    SharedPreferences sharedPreferencesSession;
    SharedPreferences.Editor editorSession;
    Context context;
    int PRIVATE_MODE = 0;
    HashMap<String, String> user;

    public Session(Context context) {

        Log.d("session called","from"+context.getClass());

        this.context = context;
        sharedPreferencesSession = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editorSession = sharedPreferencesSession.edit();
    }

    public void setLogin(boolean isLoggedIn) {

        Log.d("Isloging ","set");
        editorSession.putBoolean("isloggedin", isLoggedIn);
        editorSession.commit();
    }

    public boolean isLoggedIn() {
        if (sharedPreferencesSession.contains("isloggedin")) {
            if(sharedPreferencesSession.getBoolean("isloggedin",false)==true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else {
            return false;
        }
    }


    public void createLoginSession(JSONArray jsonArrayUser) {
        try {
            editorSession.putString(CustomerName, jsonArrayUser.getJSONObject(0).getString(CustomerName));
            editorSession.putString(MobileNo, jsonArrayUser.getJSONObject(0).getString(MobileNo));
            setLogin(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("WrongConstant")
    public void logoutUser(Context context) {

        sharedPreferencesSession = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editorSession = sharedPreferencesSession.edit();
        editorSession.clear();
        editorSession.commit();

    }

    public HashMap<String, String> getUserDetails() {

        user = new HashMap<String, String>();

        user.put(CustomerName, sharedPreferencesSession.getString(CustomerName, ""));
        user.put(MobileNo, sharedPreferencesSession.getString(MobileNo, ""));


        return user;
    }


}
