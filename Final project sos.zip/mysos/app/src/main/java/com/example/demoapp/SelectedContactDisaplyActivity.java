package com.example.demoapp;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.onegravity.contactpicker.ContactElement;
import com.onegravity.contactpicker.contact.Contact;
import com.onegravity.contactpicker.contact.ContactDescription;
import com.onegravity.contactpicker.contact.ContactSortOrder;
import com.onegravity.contactpicker.core.ContactPickerActivity;
import com.onegravity.contactpicker.group.Group;
import com.onegravity.contactpicker.picture.ContactPictureType;

import java.io.Serializable;
import java.util.List;

import io.paperdb.Paper;

import static android.provider.ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE;

public class SelectedContactDisaplyActivity extends AppCompatActivity {
    private static final int REQUEST_CONTACT = 0;
    private List<Contact> mContacts;
    private List<Group> mGroups;

    private static final String EXTRA_GROUPS = "EXTRA_GROUPS";
    private static final String EXTRA_CONTACTS = "EXTRA_CONTACTS";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            mGroups = (List<Group>) savedInstanceState.getSerializable(EXTRA_GROUPS);
            mContacts = (List<Contact>) savedInstanceState.getSerializable(EXTRA_CONTACTS);
        }

        setContentView(R.layout.activity_selected_contact_disaply);

        try {
            mContacts = Paper.book().read("contacts");
        } catch (Exception e) {
            e.printStackTrace();
        }

// configure "pick contact(s)" button
        ImageView button = (ImageView) findViewById(R.id.pick_contact);
        if (button != null) {
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(SelectedContactDisaplyActivity.this, ContactPickerActivity.class)
                            .putExtra(ContactPickerActivity.EXTRA_THEME, R.style.Theme_Light)

                            .putExtra(ContactPickerActivity.EXTRA_CONTACT_BADGE_TYPE,
                                    ContactPictureType.ROUND.name())

                            .putExtra(ContactPickerActivity.EXTRA_CONTACT_DESCRIPTION,
                                    ContactDescription.PHONE.name())
                            .putExtra(ContactPickerActivity.EXTRA_SHOW_CHECK_ALL, true)
                            .putExtra(ContactPickerActivity.EXTRA_SELECT_CONTACTS_LIMIT, 0)
                            .putExtra(ContactPickerActivity.EXTRA_ONLY_CONTACTS_WITH_PHONE, false)
                            .putExtra(ContactPickerActivity.EXTRA_WITH_GROUP_TAB, false)

                            .putExtra(ContactPickerActivity.EXTRA_CONTACT_DESCRIPTION_TYPE,
                                    ContactsContract.CommonDataKinds.Email.TYPE_WORK)

                            .putExtra(ContactPickerActivity.EXTRA_CONTACT_SORT_ORDER,
                                    ContactSortOrder.AUTOMATIC.name());

                    startActivityForResult(intent, REQUEST_CONTACT);
                }
            });
        } else {
            finish();
        }

        // populate contact list
        populateContactList(mGroups, mContacts);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CONTACT && resultCode == Activity.RESULT_OK && data != null &&
                (data.hasExtra(ContactPickerActivity.RESULT_GROUP_DATA) ||
                        data.hasExtra(ContactPickerActivity.RESULT_CONTACT_DATA))) {

            // we got a result from the contact picker --> show the picked contacts
            mGroups = (List<Group>) data.getSerializableExtra(ContactPickerActivity.RESULT_GROUP_DATA);
            mContacts = (List<Contact>) data.getSerializableExtra(ContactPickerActivity.RESULT_CONTACT_DATA);
            populateContactList(mGroups, mContacts);
            Paper.book().write("contacts", mContacts);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        if (mGroups != null) {
            outState.putSerializable(EXTRA_GROUPS, (Serializable) mGroups);
        }
        if (mContacts != null) {
            outState.putSerializable(EXTRA_CONTACTS, (Serializable) mContacts);
        }
    }

    private void populateContactList(List<Group> groups, List<Contact> contacts) {
        // we got a result from the contact picker --> show the picked contacts
        TextView contactsView = (TextView) findViewById(R.id.contacts);
        SpannableStringBuilder result = new SpannableStringBuilder();

        try {
            if (groups != null && !groups.isEmpty()) {
//                result.append("\n");
                for (Group group : groups) {
                    populateContact(result, group, "");
                    for (Contact contact : group.getContacts()) {
                        populateContact(result, contact, "    ");
                    }
                }
            }
            if (contacts != null && !contacts.isEmpty()) {
//                result.append("\n");
                for (Contact contact : contacts) {
                    populateContact(result, contact, "");
                }
            }
        } catch (Exception e) {
            result.append(e.getMessage());
        }

        contactsView.setText(result);
    }

    private void populateContact(SpannableStringBuilder result, ContactElement element, String prefix) {
        //int start = result.length();
        String displayName = element.getDisplayName();
        result.append(prefix);
        result.append(displayName + "\n");


        //result.setSpan(new BulletSpan(15), start, result.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
    }


    private void populateContact(SpannableStringBuilder result, Contact element, String prefix) {
        //int start = result.length();
        String displayName = element.getDisplayName();
        result.append(prefix);
        result.append(displayName + "\n");
        result.append(element.getPhone(TYPE_MOBILE) + "\n");

        //result.setSpan(new BulletSpan(15), start, result.length(), Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
    }


}