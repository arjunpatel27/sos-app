package com.example.demoapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

public class RegisterActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    EditText edit_full_name, edit_email, edit_mobileno, edit_password, edit_re_password,edit_ans;
    Button btn_signup;

    Pattern ptrn;
    Matcher mtc;
    RelativeLayout rl_progress_container;
    UserModel userModel;


    String[] country = {
            "In what city were you born?",
            "What is the name of your favorite pet?",
            "What is your mother's maiden name?",
            "What high school did you attend?",
            "What was the name of your elementary school?",
            "What was the make of your first car?",
            "What was your favorite food as a child?",
            "Where did you meet your spouse?",
            "What year was your father (or mother) born?"
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        rl_progress_container = findViewById(R.id.progress_container);
        edit_full_name = findViewById(R.id.edit_full_name);
        edit_email = findViewById(R.id.edit_email);
        edit_mobileno = findViewById(R.id.edit_mobileno);
        edit_password = findViewById(R.id.edit_password);
        edit_re_password = findViewById(R.id.edit_re_password);
        edit_ans = findViewById(R.id.edit_ans);
        btn_signup = findViewById(R.id.btn_signup);

        Spinner spin = (Spinner) findViewById(R.id.spinner);
        spin.setOnItemSelectedListener(this);

        //Creating the ArrayAdapter instance having the country list
        ArrayAdapter aa = new ArrayAdapter(this,R.layout.spinner_item,country);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        spin.setAdapter(aa);
        question = country[0];

        btn_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveCourse();
//                Intent inten = new Intent(RegisterActivity.this, LoginActivity.class);
//                startActivity(inten);
//                getimei();
            }
        });
    }

    private void saveCourse() {

        String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        ptrn = Pattern.compile("\\d{10,11}");
        mtc = ptrn.matcher(edit_mobileno.getText().toString());

        if (edit_full_name.getText().toString().isEmpty()) {
            Toast.makeText(RegisterActivity.this, "Please enter full name.", Toast.LENGTH_SHORT).show();
        } else if (edit_mobileno.toString().isEmpty()) {
            Toast.makeText(RegisterActivity.this, "Please enter mobile number.", Toast.LENGTH_SHORT).show();
        } else if (edit_email.getText().toString().isEmpty()) {
            Toast.makeText(RegisterActivity.this, "Please enter email id.", Toast.LENGTH_SHORT).show();
        } else if (!edit_email.getText().toString().matches(EMAIL_PATTERN)) {
            Toast.makeText(RegisterActivity.this, "Please enter valid email id.", Toast.LENGTH_SHORT).show();
        } else if (!mtc.matches()) {
            Toast.makeText(RegisterActivity.this, "Please enter valid mobile number.", Toast.LENGTH_SHORT).show();
        } else if (edit_password.getText().toString().isEmpty()) {
            Toast.makeText(RegisterActivity.this, "Please enter password", Toast.LENGTH_SHORT).show();
        } else if (edit_password.getText().length() < 8) {
            Toast.makeText(RegisterActivity.this, "Password Length Must be 8 character.", Toast.LENGTH_SHORT).show();
        } else if (edit_re_password.getText().toString().isEmpty()) {
            Toast.makeText(RegisterActivity.this, "Please enter confirm password", Toast.LENGTH_SHORT).show();
        } else if (!edit_re_password.getText().toString().equals(edit_password.getText().toString())) {
            Toast.makeText(RegisterActivity.this, "Confirm Password Doesn't Match", Toast.LENGTH_SHORT).show();
        } else if (edit_ans.getText().toString().isEmpty()) {
            Toast.makeText(RegisterActivity.this, "Please enter ans", Toast.LENGTH_SHORT).show();
        } else {
            if (edit_email.getText().toString().trim().matches(EMAIL_PATTERN)) {
                if (userModel == null) {
                    UserDB UserDatabase = UserDB.getInstance(getApplicationContext());
                    UserDao userDao = UserDatabase.userDao();
                    UserModel course = userDao.check(edit_email.getText().toString());
                    UserModel mobile = userDao.findByNumber(edit_mobileno.getText().toString());

                    if (course != null) {
                        Toast.makeText(getApplicationContext(), "Email is already exist in Database", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    else if (mobile != null) {
                        Toast.makeText(getApplicationContext(), "Mobile Number is already exist in Database", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    UserModel model = new UserModel(edit_full_name.getText().toString(), edit_mobileno.getText().toString(),
                            edit_email.getText().toString(), edit_password.getText().toString(),question,edit_ans.getText().toString());
                    UserDatabase.userDao().insert(model);
                } else {
                    userModel.setFullName(edit_full_name.getText().toString());
                    userModel.setPhone(edit_mobileno.getText().toString());
                    userModel.setEmail(edit_email.getText().toString());
                    userModel.setPassword(edit_password.getText().toString());
                }
                finish();
                Toast.makeText(this, "Register successfully!", Toast.LENGTH_SHORT).show();
            } else {
                edit_full_name.setError("Invalid Email Address");
            }
        }
    }


    private void checkRunTimePermission() {
        String[] permissionArrays = new String[]{WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_PHONE_STATE};
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(permissionArrays, 11111);
            Log.d("imei==", imei + "");
        } else {
            Log.d("imei==", imei + "");
            // if already permition granted
            // PUT YOUR ACTION (Like Open cemara etc..)
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 11111) {
            getimei();
        }
    }

    private void getimei() {
        if (ActivityCompat.checkSelfPermission(RegisterActivity.this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            checkRunTimePermission();
            return;
        }
        imei = getDeviceIMEI();
        Log.d("imei==", imei + "");
    }

    public String getDeviceIMEI() {
        String deviceUniqueIdentifier = "";
//        TelephonyManager tm = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
//        if (null != tm) {
//            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
//                return "No";
//            }
//            deviceUniqueIdentifier = tm.getDeviceId();
//        }
//        if (null == deviceUniqueIdentifier || 0 == deviceUniqueIdentifier.length()) {
//            deviceUniqueIdentifier = Settings.Secure.getString(this.getContentResolver(), Settings.Secure.ANDROID_ID);
//        }
        return deviceUniqueIdentifier;
    }

    String imei = "";
    String question = "";

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
//        Toast.makeText(getApplicationContext(),country[i] , Toast.LENGTH_LONG).show();
        question = country[i];
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
