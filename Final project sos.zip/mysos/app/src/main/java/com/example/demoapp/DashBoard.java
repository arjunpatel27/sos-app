package com.example.demoapp;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.SystemClock;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;

import com.pixplicity.easyprefs.library.Prefs;
import com.wafflecopter.multicontactpicker.ContactResult;

import org.json.JSONObject;

import java.lang.reflect.Member;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import io.paperdb.Paper;

import static android.Manifest.permission.ACCESS_COARSE_LOCATION;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

public class DashBoard extends AppCompatActivity  implements View.OnClickListener {
    LinearLayout rl_progress_container,btn;
    ImageView sos;
    CardView cview1,cview2,cview5;
    private Camera camera;
    private boolean isFlashOn;
    private boolean hasFlash;
    private Camera.Parameters params;
    Session session;
    private int blinkingSpeed = 1;
    HashMap<String, String> hashMap = new HashMap<>();
    GPSTracker gps;
    String imei = "";


long delay=50;
    private int count;
    public static final String NOTIFICATION_CHANNEL_ID = "10001" ;
    final static String default_notification_channel_id = "default" ;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);
        rl_progress_container = findViewById(R.id.progress_container);
        btn= findViewById(R.id.btn_sos);

        //cview1=findViewById(R.id.sos);
        cview2=findViewById(R.id.cview2);
//        cview5=findViewById(R.id.cView5);
        sos=findViewById(R.id.image1);
        session = new Session(this);
        hashMap = session.getUserDetails();
        checkRunTimePermission();
        getDeviceIMEI();
        statusCheck();
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);




        cview2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),user_Detail.class);
                startActivity(intent);
            }


        });

//        cview5.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent=new Intent(getApplicationContext(),policy_reminder.class);
//                startActivity(intent);
//            }
//        });


        hasFlash = getApplicationContext().getPackageManager()
                .hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);

        if (!hasFlash) {
            // device doesn't support flash
            // Show alert message and close the application
            android.app.AlertDialog alert = new android.app.AlertDialog.Builder(DashBoard.this)
                    .create();
            alert.setTitle("Error");
            alert.setMessage("Sorry, your device doesn't support flash light!");
            alert.setButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    // closing the application
                    finish();
                }
            });
            alert.show();
            return;
        }
//        sos.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//
//                Intent snoozeIntent = new Intent(DashBoard. this, DashBoard. class ) ;
//                snoozeIntent.setAction( "ACTION_SNOOZE" ) ;
//                snoozeIntent.putExtra( "EXTRA_NOTIFICATION_ID" , 0 ) ;
//                PendingIntent snoozePendingIntent = PendingIntent. getBroadcast (DashBoard. this, 0 , snoozeIntent , 0 ) ;
//                NotificationManager mNotificationManager = (NotificationManager) getSystemService( NOTIFICATION_SERVICE ) ;
//                NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(DashBoard. this, default_notification_channel_id ) ;
//                mBuilder.setContentTitle( "Emergancy Help Required" ) ;
//                mBuilder.setContentText( "SOS Button Pressed" ) ;
//                mBuilder.setTicker( "User Required Help" ) ;
//                mBuilder.setSmallIcon(R.drawable. ic_launcher_foreground ) ;
//                mBuilder.setAutoCancel( true ) ;
//                if (Build.VERSION. SDK_INT >= Build.VERSION_CODES. O ) {
//                    int importance = NotificationManager. IMPORTANCE_HIGH ;
//                    NotificationChannel notificationChannel = new NotificationChannel( NOTIFICATION_CHANNEL_ID , "SOS Notification" ,NotificationManager.IMPORTANCE_HIGH) ;
//                    mBuilder.setChannelId( NOTIFICATION_CHANNEL_ID ) ;
//                    assert mNotificationManager != null;
//                    mNotificationManager.createNotificationChannel(notificationChannel) ;
//
//                }
//                assert mNotificationManager != null;
//                mNotificationManager.notify(( int ) System. currentTimeMillis () , mBuilder.build()) ;
//
//
//                if (isFlashOn) {
//                    // turn off flash
//                    turnOffFlash();
//
//
//                } else {
//                    // turn on flash
//                   turnOnFlash();
//                }
//            }
//        });
        // get the camera
        getCamera();
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onClick(View v) {

//    AlertDialog.Builder alert = new AlertDialog.Builder(this);
////        alert.setTitle("Do you want to Reject request");
////        alert.setIcon(android.R.drawable.ic_dialog_alert);
////        alert.setPositiveButton("yes", new DialogInterface.OnClickListener() {
////            public void onClick(DialogInterface dialog, int which) {
////            } });
////
////        alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
////            public void onClick(DialogInterface dialog, int which) {
////                // finish();
////            } });
////        alert.show();
////



        switch (v.getId()) {
            case R.id.btn_sos:
                Intent snoozeIntent = new Intent(DashBoard. this, DashBoard. class ) ;
                snoozeIntent.setAction( "ACTION_SNOOZE" ) ;
                snoozeIntent.putExtra( "EXTRA_NOTIFICATION_ID" , 0 ) ;
                PendingIntent snoozePendingIntent = PendingIntent. getBroadcast (DashBoard. this, 0 , snoozeIntent , 0 ) ;
                NotificationManager mNotificationManager = (NotificationManager) getSystemService( NOTIFICATION_SERVICE ) ;
                NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(DashBoard. this, default_notification_channel_id ) ;
                mBuilder.setContentTitle( "Emergancy Help Required" ) ;
                mBuilder.setContentText( "SOS Button Pressed" ) ;
                mBuilder.setTicker( "User Required Help" ) ;
                mBuilder.setSmallIcon(R.drawable. ic_launcher_foreground ) ;
                mBuilder.setAutoCancel( true ) ;
                if (Build.VERSION. SDK_INT >= Build.VERSION_CODES. O ) {
                    int importance = NotificationManager. IMPORTANCE_HIGH ;
                    NotificationChannel notificationChannel = new NotificationChannel( NOTIFICATION_CHANNEL_ID , "SOS Notification" ,NotificationManager.IMPORTANCE_HIGH) ;
                    mBuilder.setChannelId( NOTIFICATION_CHANNEL_ID ) ;
                    assert mNotificationManager != null;
                    mNotificationManager.createNotificationChannel(notificationChannel) ;

                }
                assert mNotificationManager != null;
                mNotificationManager.notify(( int ) System. currentTimeMillis () , mBuilder.build()) ;

                Toast.makeText(DashBoard.this, "permission required", Toast.LENGTH_SHORT).show();
                MediaPlayer mediaPlayer = MediaPlayer.create(this, R.raw.emergency);
                mediaPlayer.start();
                blink();
            try {

//                if (location.onProviderDisabled()){
//                    location.onProviderDisabled();
//                    Toast.makeText(DashBoard.this, "please enable gps and internet", Toast.LENGTH_SHORT).show();
//                }




                    gps = new GPSTracker(DashBoard.this);

                    // Check if GPS enabled
                    if (gps.canGetLocation()) {



                        double latitude = gps.getLatitude();
                        double longitude = gps.getLongitude();

                        rl_progress_container.setVisibility(View.VISIBLE);
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("name", hashMap.get(Session.CustomerName));
                        jsonObject.put("phone", hashMap.get(Session.MobileNo));
                        jsonObject.put("lat", String.valueOf(latitude));
                        jsonObject.put("lon", String.valueOf(longitude));
                        jsonObject.put("imei", imei);
                        RequestTask testTask = new RequestTask() {
                            @Override
                            protected void onPostExecute(String result) {
                                try {


                                    rl_progress_container.setVisibility(View.GONE);
                                    if (result != null) {
                                        Toast.makeText(DashBoard.this, "If you have selected your Contact already then sms send successfully ", Toast.LENGTH_SHORT).show();
                                        Log.d("Service=", "" + result);
//                                    serviceResult = result;
//                                    latch.countDown();
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        };
                        testTask.execute("ping", jsonObject.toString());
                        // \n is for new line
                        try {
                            List<ContactResult> results = Paper.book().read("contacts");

                            if (results != null) {
                                String address = "";

                                for (ContactResult contactResult : results) {
                                    if (contactResult.getPhoneNumbers().size() > 0) {
//                                        address += contactResult.getPhoneNumbers().get(0).getNumber();
//                                        address += contactResult.getDisplayName();
//                                        address += ";";
                                        StringBuilder message = new StringBuilder();
                                        message.append(hashMap.get(Session.CustomerName) + "" + hashMap.get(Session.MobileNo) +" Emergency Help Required (sos button pressed) user Last location is ");
                                        message.append("http://maps.google.com/maps?q=");
                                        message.append(jsonObject.getString("lat"));
                                        message.append(",");
                                        message.append(jsonObject.getString("lon"));
                                        message.append("you can see this person area in many Hospital avaliable so Please Help this person and Save Their Life.");
                                        message.append("Contact This Person  make sure he/she is safe.");
                                        message.append("NGO Details:- Smile foundation(+91-11-43123700),HelpAge India(1800-180-1253/020 2026 5513)");
                                        SmsManager smsManager = SmsManager.getDefault();
                                        ArrayList<String> parts = smsManager.divideMessage(message.toString());
                                        smsManager.sendMultipartTextMessage(contactResult.getPhoneNumbers().get(0).getNumber(), null, parts, null, null);

//                                        SmsManager smsManager =  SmsManager.getDefault();
//                                        smsManager.sendTextMessage(contactResult.getPhoneNumbers().get(0).getNumber(),null, message.toString(), null, null);
                                    }
                                }


                                Log.e("contact=", address + "");
//                                Intent i = new Intent(android.content.Intent.ACTION_VIEW);
//                                i.putExtra("address", address);
//                                i.putExtra("sms_body", message.toString());
//                                i.setType("vnd.android-dir/mms-sms");
//                                startActivity(i);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    } else {
                        // Can't get location.
                        // GPS or network is not enabled.
                        // Ask user to enable GPS/network in settings.
                        gps.showSettingsAlert();
                    }

                }



                catch (Exception e) {
                    Toast.makeText(DashBoard.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.btn_logout:
//                session.logoutUser(this);
//                startActivity(new Intent(this, LoginActivity.class));
//                finish();

                // Logout Dialog
                AlertDialog.Builder builder;
                builder = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.CustomDialogTheme));
                builder.setMessage("Are you sure want to Logout?").setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialog, int id) {
                                Prefs.clear();
                                finish();
                                Intent login = new Intent(DashBoard.this, LoginActivity.class);
                                startActivity(login);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }

                        }).show();
               break;
            case R.id.cview3:
                startActivity(new Intent(this, Bloodbank.class));
                break;
            case R.id.btn_setting:
                startActivity(new Intent(this, SettingContact.class));
                break;

        }



    }




    private void getimei() {
        if (ActivityCompat.checkSelfPermission(DashBoard.this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            checkRunTimePermission();
            return;
        }
        imei = getDeviceIMEI();
        Log.d("imei==", imei + "");
    }

    private void checkRunTimePermission() {
        String[] permissionArrays = new String[]{WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_PHONE_STATE, Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS,Manifest.permission.CAMERA, Manifest.permission.READ_CONTACTS, ACCESS_FINE_LOCATION, ACCESS_COARSE_LOCATION};
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            requestPermissions(permissionArrays, 11111);
            Log.d("imei==", imei + "");
        } else {
            Log.d("imei==", imei + "");
            // if already permition granted
            // PUT YOUR ACTION (Like Open cemara etc..)
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 11111) {
            getimei();
        }
    }

    public String getDeviceIMEI() {
        String deviceUniqueIdentifier = "null";
//        TelephonyManager tm = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
//        if (null != tm) {
//            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
//                return "No";
//            }
//            deviceUniqueIdentifier = tm.getDeviceId();
//        }
//        if (null == deviceUniqueIdentifier || 0 == deviceUniqueIdentifier.length()) {
//            deviceUniqueIdentifier = Settings.Secure.getString(this.getContentResolver(), Settings.Secure.ANDROID_ID);
//        }
        return deviceUniqueIdentifier;
    }

    public void statusCheck() {
        final LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            buildAlertMessageNoGps();

        }
    }

    private void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Your GPS seems to be disabled, do you want to enable it?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        dialog.cancel();
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder Exit=new AlertDialog.Builder(this);
        Exit.setTitle("Exit?");
        Exit.setIcon(R.drawable.alert);
        Exit.setMessage("Are you sure want to exit?");

        Exit.setPositiveButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent=new Intent(getApplicationContext(),DashBoard.class);
                startActivity(intent);
            }
        });
        Exit.setNegativeButton("yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finishAffinity();
            }
        });
        Exit.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        Exit.show();

    }

    private void getCamera() {
        if (camera == null) {
            try {
                camera = Camera.open();
                params = camera.getParameters();
            } catch (RuntimeException e) {

            }
        }
    }

    /*
     * Turning On flash
//     */
//    private void turnOnFlash() {
//        SystemClock.sleep(200);
//        int led = 1;
//        if (!isFlashOn) {
//
//            count++;
//
//            if (camera == null || params == null) {
//                return;
//            }
//
//
//            params = camera.getParameters();
//            params.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
//            camera.setParameters(params);
//            camera.startPreview();
//            isFlashOn = true;
//
//            count++;
//
//            if(led ==1){
//                count =0;
//
//            }
//        }
//
//    }
//
//    /*
//     * Turning Off flash
//     */
//    private void turnOffFlash() {
//        if (isFlashOn) {
//
//
//            if (camera == null || params == null) {
//                return;
//            }
//
//            params = camera.getParameters();
//            params.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
//            camera.setParameters(params);
//            camera.stopPreview();
//            isFlashOn = false;
//
//
//        }
//    }



    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
//
//    @Override
//    protected void onPause() {
//        super.onPause();
//
//
//        if(isFlashOn){
//            count =0;
//
//            turnOffFlash();
//        }
//    }
    @Override
    protected void onRestart() {
        super.onRestart();
    }



    @Override
    protected void onResume() {
        super.onResume();

        // on resume turn on the flash
    }

    @Override
    protected void onStart() {
        super.onStart();

        // on starting the app get the camera params
        getCamera();
    }

//
//
//    @Override
//    protected void onStop() {
//        super.onStop();
//
//        // on stop release the camera
//        if(isFlashOn){
//            count =0;
//            turnOffFlash();
//
//        }
//    }

    @RequiresApi(api=Build.VERSION_CODES.M)
    private void turnOffFlash(){
        CameraManager cameraManager =(CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try{
            String cameraid= cameraManager.getCameraIdList()[0];
            cameraManager.setTorchMode(cameraid,false);
        }catch (CameraAccessException e){}
    }

    @RequiresApi(api=Build.VERSION_CODES.M)
    private void turnOnFlash(){
        CameraManager cameraManager =(CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try{
            String cameraid= cameraManager.getCameraIdList()[0];
            cameraManager.setTorchMode(cameraid,true);
        }catch (CameraAccessException e){}
    }

@RequiresApi(api = Build.VERSION_CODES.M)
public void blink(){

    CameraManager cameraManager =(CameraManager) getSystemService(Context.CAMERA_SERVICE);
    String mystring="01010101010101010101";
    long blinkdelay=100;
    for(int i=0;i<mystring.length();i++){
        if(mystring.charAt(i)=='0'){
            params = camera.getParameters();
            params.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
            camera.setParameters(params);
            camera.startPreview();
            try{

                String cameraid= cameraManager.getCameraIdList()[0];
                cameraManager.setTorchMode(cameraid,true);
            }catch (CameraAccessException e){}
        }
        else
        {   params = camera.getParameters();
            params.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
            camera.setParameters(params);
            camera.stopPreview();

            try{
                String cameraid= cameraManager.getCameraIdList()[0];
                cameraManager.setTorchMode(cameraid,false);
            }catch (CameraAccessException e){}}
        try{
            Thread.sleep(blinkdelay);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

    }
}


}


