package com.example.demoapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Camera;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import static android.Manifest.permission.ACCESS_COARSE_LOCATION;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.pixplicity.easyprefs.library.Prefs;

public class LoginActivity extends AppCompatActivity {
    EditText edit_emailid, edit_password;
    TextView txt_signup, txt_forgot_pass;
    TextView btn_signin;
    SharedPreferences preferences;
    RelativeLayout rl_progress_container;
    Session session;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    Userinfo userinfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        checkRunTimePermission();


        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Userinfo");
        session = new Session(this);
        userinfo = new Userinfo();
//        if (session.isLoggedIn()) {
        if (false) {
            Intent i = new Intent(this, DashBoard.class);
            startActivity(i);
            finish();
        }

        preferences = getSharedPreferences("USER_PREFRENCE", Activity.MODE_PRIVATE);

        edit_emailid = findViewById(R.id.edit_emailid);
        edit_password = findViewById(R.id.edit_password);

        txt_signup = findViewById(R.id.txt_signup);
        txt_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
            }
        });

        txt_forgot_pass = findViewById(R.id.txt_forgot_pass);
        txt_forgot_pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this, ForgotPassword.class));
            }
        });

        btn_signin = findViewById(R.id.btn_signin);
        rl_progress_container = findViewById(R.id.progress_container);
        btn_signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String password = edit_password.getText().toString();
                addDatatoFirebase(password);
                if (edit_emailid.getText().toString().isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please enter mobile.", Toast.LENGTH_SHORT).show();
                } else if (edit_password.getText().toString().isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please enter password.", Toast.LENGTH_SHORT).show();
                } else {


                    UserDB UserDatabase = UserDB.getInstance(getApplicationContext());
                    UserDao userDao = UserDatabase.userDao();
                    UserModel course = userDao.login(edit_emailid.getText().toString(), edit_password.getText().toString());
                    if (course == null) {
                        Toast.makeText(LoginActivity.this, "Phone or Password is invalid!.", Toast.LENGTH_SHORT).show();
                    } else {
                        Prefs.putBoolean("isLogin",true);
                        Intent intent = new Intent(LoginActivity.this, DashBoard.class);
                        startActivity(intent);
                        finish();

                    }

//                    try {
//                        rl_progress_container.setVisibility(View.VISIBLE);
//                        final JSONObject jsonObject = new JSONObject();
//                        jsonObject.put("phone", edit_emailid.getText());
//                        jsonObject.put("password", edit_password.getText());
//                        RequestTask testTask = new RequestTask() {
//                            @Override
//                            protected void onPostExecute(String result) {
//                                try {
//                                    rl_progress_container.setVisibility(View.GONE);
//                                    if (result != null) {
//                                        JSONObject jsonObject1 = new JSONObject(result);
//                                        if (jsonObject1.getJSONArray("data") != null) {
////                                            Toast.makeText(LoginActivity.this, "User Login Successfully", Toast.LENGTH_SHORT).show();
//                                            session.createLoginSession(jsonObject1.getJSONArray("data"));
//                                            Intent intent = new Intent(LoginActivity.this, DashBoard.class);
//                                            startActivity(intent);
//                                            finish();
//                                        } else {
//                                            Toast.makeText(LoginActivity.this, "Wrong phonr and password...", Toast.LENGTH_SHORT).show();
//                                        }
//                                        Log.d("Service=", "" + result);
//                                    }
//                                } catch (Exception e) {
//                                    Toast.makeText(LoginActivity.this, "Wrong phone and password...", Toast.LENGTH_SHORT).show();
//                                    e.printStackTrace();
//                                }
//                            }
//                        };
//                        testTask.execute("verfiy", jsonObject.toString());

//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }

//
                }
            }
        });


    }

    public void onBackPressed() {

        AlertDialog.Builder Exit=new AlertDialog.Builder(this);
        Exit.setTitle("Exit?");
        Exit.setIcon(R.drawable.ic_baseline_exit_to_app_24);
        Exit.setMessage("Are you sure want to exit?");

        Exit.setPositiveButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent=new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(intent);
            }
        });
        Exit.setNegativeButton("yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                LoginActivity.super.onBackPressed();
            }
        });
        Exit.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        Exit.show();
    }

    private void checkRunTimePermission() {
        String[] permissionArrays = new String[]{WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_PHONE_STATE, Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS,Manifest.permission.CAMERA ,  Manifest.permission.READ_CONTACTS, ACCESS_FINE_LOCATION, ACCESS_COARSE_LOCATION};
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(permissionArrays, 11111);
        } else {

        }
    }

    private void addDatatoFirebase(String password){


     //   userinfo.setPassword(password);



        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                databaseReference.setValue(userinfo);


                Toast.makeText(LoginActivity.this, "data added", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

                Toast.makeText(LoginActivity.this, "Fail to add data " + error, Toast.LENGTH_SHORT).show();
            }


        });
}}