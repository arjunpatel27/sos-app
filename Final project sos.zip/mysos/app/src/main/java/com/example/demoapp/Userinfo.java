package com.example.demoapp;

import android.widget.CheckBox;

public class Userinfo {
   // private String password;
    private String userName;
    private String useradharNumber;
    private String userAddress;
    private String userEmail;
    private String BirthDate;
    private String Age;
    private String Pincode;
    private String PolicyNumber;
    private String PolicyAmount;
    private String PolicyStartDate;
    private String PolicyEndDate;
    private String IllnessName;
    private String NameOfinjection;
    private String NameOfTablet;
    private String NameOfSyrup;
    private  String Blood;
    private String insurancecompany;
    private String state;
    private String district;
    private String typeofmedicine;
    private String gender;
    private String insurancepolicyAvaliable;
    private String illnessavaliable;
    private String Medicinetakedaily;
    private String dailymedicinetake;

    public Userinfo() {

    }

    public String getDailymedicinetake() {
        return dailymedicinetake;
    }

    public void setDailymedicinetake(String dailymedicinetake) {
        this.dailymedicinetake = dailymedicinetake;
    }

    public String getMedicinetakedaily() {
        return Medicinetakedaily;
    }

    public void setMedicinetakedaily(String medicinetakedaily) {
        Medicinetakedaily = medicinetakedaily;
    }

    public String getIllnessavaliable() {
        return illnessavaliable;
    }

    public void setIllnessavaliable(String illnessavaliable) {
        this.illnessavaliable = illnessavaliable;
    }

    public String getInsurancepolicyAvaliable() {
        return insurancepolicyAvaliable;
    }

    public void setInsurancepolicyAvaliable(String insurancepolicyAvaliable) {
        this.insurancepolicyAvaliable = insurancepolicyAvaliable;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getTypeofmedicine() {
        return typeofmedicine;
    }

    public void setTypeofmedicine(String typeofmedicine) {
        this.typeofmedicine = typeofmedicine;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getInsurancecompany() {
        return insurancecompany;
    }

    public void setInsurancecompany(String insurancecompany) {
        this.insurancecompany = insurancecompany;
    }

    public String getBlood() {
        return Blood;
    }

    public void setBlood(String blood) {
        Blood = blood;
    }

//    public String getPassword () {
//            return password;
//        }
//
//        public void setPassword (String password){
//            this.password = password;
//        }

        public String getNameOfTablet () {
            return NameOfTablet;
        }

        public void setNameOfTablet (String nameOfTablet){
            NameOfTablet = nameOfTablet;
        }

        public String getNameOfSyrup () {
            return NameOfSyrup;
        }


        public void setNameOfSyrup (String nameOfSyrup){
            NameOfSyrup = nameOfSyrup;
        }

        public String getNameOfinjection () {
            return NameOfinjection;
        }

        public void setNameOfinjection (String nameOfinjection){
            NameOfinjection = nameOfinjection;
        }

        public String getIllnessName () {
            return IllnessName;
        }

        public void setIllnessName (String illnessName){
            IllnessName = illnessName;
        }

        public String getPolicyEndDate () {
            return PolicyEndDate;
        }

        public void setPolicyEndDate (String policyEndDate){
            PolicyEndDate = policyEndDate;
        }

        public String getPolicyStartDate () {
            return PolicyStartDate;
        }

        public void setPolicyStartDate (String policyStartDate){
            PolicyStartDate = policyStartDate;
        }

        public String getPolicyAmount () {
            return PolicyAmount;
        }

        public void setPolicyAmount (String policyAmount){
            PolicyAmount = policyAmount;
        }

        public String getPolicyNumber () {
            return PolicyNumber;
        }

        public void setPolicyNumber (String policyNumber){
            PolicyNumber = policyNumber;
        }

        public String getPincode () {
            return Pincode;
        }

        public void setPincode (String pincode){
            this.Pincode = pincode;
        }

        public String getAge () {
            return Age;
        }

        public void setAge (String age){
            this.Age = age;
        }

        public String getBirthDate () {
            return BirthDate;
        }

        public void setBirthDate (String BirthDate){
            this.BirthDate = BirthDate;

        }

        public String getUserName () {
            return userName;
        }

        public void setUserName (String userName){
            this.userName = userName;
        }

        public String getUseradharNumber () {
            return useradharNumber;
        }

        public void setUseradharNumber (String useradharNumber){
            this.useradharNumber = useradharNumber;
        }

        public String getUserAddress () {
            return userAddress;
        }

        public void setUserAddress (String userAddress){
            this.userAddress = userAddress;
        }

        public String getUserEmail () {
            return userEmail;
        }
        public void setUserEmail (String userEmail){
            this.userEmail = userEmail;

        }

    public void setTypeofmedicine(CheckBox c1, CheckBox c2, CheckBox c3) {
    }
}



