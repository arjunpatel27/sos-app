package com.example.demoapp;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ChangePassword extends AppCompatActivity {
    EditText edit_password, edit_re_password;
    Button btn_signup;


    UserModel userModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        userModel = (UserModel) getIntent().getSerializableExtra("user");
        Log.e("User==",userModel.fullName+"");
        edit_password = findViewById(R.id.edit_password);
        edit_re_password = findViewById(R.id.edit_re_password);
        btn_signup = findViewById(R.id.btn_signup);
        btn_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edit_password.getText().toString().isEmpty()) {
                Toast.makeText(ChangePassword.this, "Please enter password", Toast.LENGTH_SHORT).show();
            } else if (edit_password.getText().length() < 8) {
                Toast.makeText(ChangePassword.this, "Password Length Must be 8 character.", Toast.LENGTH_SHORT).show();
            } else if (edit_re_password.getText().toString().isEmpty()) {
                Toast.makeText(ChangePassword.this, "Please enter confirm password", Toast.LENGTH_SHORT).show();
            } else if (!edit_re_password.getText().toString().equals(edit_password.getText().toString())) {
                    Toast.makeText(ChangePassword.this, "Confirm Password Doesn't Match", Toast.LENGTH_SHORT).show();
                }else{
                    userModel.setPassword(edit_password.getText().toString().trim());
                    UserDB UserDatabase = UserDB.getInstance(getApplicationContext());
                    UserDao userDao = UserDatabase.userDao();
                    userDao.update(userModel);
                    Toast.makeText(ChangePassword.this, "Password change Successfully", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
    }
}