package com.example.demoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageView;

public class Bloodbank extends AppCompatActivity {
    ImageView img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bloodbank);

        img=findViewById(R.id.backbtn3);

        WebView mywebview = (WebView) findViewById(R.id.webView);
        mywebview.loadUrl("https://www.eraktkosh.in/BLDAHIMS/bloodbank/stockAvailability.cnt");
        WebSettings webSettings=mywebview.getSettings();
        webSettings.setJavaScriptEnabled(true);

    }
    public void back(View view) {
        finish();
    }
}