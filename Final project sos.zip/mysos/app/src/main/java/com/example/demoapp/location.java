package com.example.demoapp;

import android.location.Location;
import android.location.LocationListener;
import android.widget.Toast;

import androidx.annotation.NonNull;

public class location implements LocationListener {


    public static boolean onProviderDisabled() {

        return true;
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}
