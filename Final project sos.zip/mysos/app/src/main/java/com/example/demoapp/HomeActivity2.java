package com.example.demoapp;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity2 extends AppCompatActivity {
    Button btn_logout;
    RelativeLayout rl_main;
    Button btn_save_our_soul, btn_zone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_2);

        rl_main = findViewById(R.id.rl_main);
        btn_zone = findViewById(R.id.btn_zone);
        btn_save_our_soul = findViewById(R.id.btn_save_our_soul);
        btn_save_our_soul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                rl_main.setBackgroundColor(Color.parseColor("#f48d87"));
//                btn_save_our_soul.setBackgroundColor(Color.parseColor("#e7535f"));
//                btn_zone.setBackgroundColor(Color.parseColor("#e7535f"));
//                btn_zone.setText("RED");
            }
        });

        btn_logout = findViewById(R.id.btn_logout);
        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log_out_Dialog();
            }
        });

    }

    // Logout Dialog
    public void Log_out_Dialog() {
        AlertDialog.Builder builder;
        builder = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.CustomDialogTheme));
        builder.setMessage("Are you sure want to Logo   ut?").setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int id) {
                        Clear_Shared_Preference(HomeActivity2.this);
                        finish();
                        Intent login = new Intent(HomeActivity2.this, LoginActivity.class);
                        startActivity(login);
                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }

        }).show();
    }

    // CLEAR ALL SHARED PREFERENCE
    public static void Clear_Shared_Preference(Context c) {
        SharedPreferences clear_user = c.getSharedPreferences("USER_PREFRENCE", MODE_PRIVATE);
        clear_user.edit().clear().commit();
    }
}