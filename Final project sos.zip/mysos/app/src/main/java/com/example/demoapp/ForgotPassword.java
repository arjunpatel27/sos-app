package com.example.demoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ForgotPassword extends AppCompatActivity {

    EditText  edit_ans, edit_mobileno;
    Button btn_signup,btn_find;

    Pattern ptrn;
    Matcher mtc;
    RelativeLayout rl_progress_container;
    TextView txt_question;

    Context context;
    UserModel userModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);


        context = this;
        rl_progress_container = findViewById(R.id.progress_container);
        edit_ans = findViewById(R.id.edit_ans);
        edit_mobileno = findViewById(R.id.edit_mobileno);
        txt_question = findViewById(R.id.txt_question);

        btn_signup = findViewById(R.id.btn_signup);
        btn_find = findViewById(R.id.btn_find);
        btn_find.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UserDB UserDatabase = UserDB.getInstance(getApplicationContext());
                UserDao userDao = UserDatabase.userDao();
                userModel = userDao.findByNumber(edit_mobileno.getText().toString());
                if(userModel==null){
                    Toast.makeText(getApplicationContext(), "User Not found", Toast.LENGTH_SHORT).show();
                }else{
                    txt_question.setText(userModel.question);
                }

            }
        });
        btn_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                        + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
                ptrn = Pattern.compile("\\d{10,11}");
                mtc = ptrn.matcher(edit_mobileno.getText().toString());

                if (userModel==null) {
                    Toast.makeText(context, "Please enter mobile.", Toast.LENGTH_SHORT).show();
                } else if (edit_mobileno.toString().isEmpty()) {
                    Toast.makeText(context, "Please enter mobile number.", Toast.LENGTH_SHORT).show();
                } else if (edit_ans.toString().isEmpty()) {
                    Toast.makeText(context, "Please enter ans.", Toast.LENGTH_SHORT).show();
                } else if (!mtc.matches()) {
                    Toast.makeText(context, "Please enter valid mobile number.", Toast.LENGTH_SHORT).show();
                }  else {


                    if(edit_ans.getText().toString().trim().equalsIgnoreCase(userModel.ans.trim())){
                            Intent intent = new Intent(getApplicationContext(),ChangePassword.class);

                        intent.putExtra("user",userModel);
                        startActivity(intent);
                        finish();
                    }else{
                        Toast.makeText(context, "Your ans not match try again", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
